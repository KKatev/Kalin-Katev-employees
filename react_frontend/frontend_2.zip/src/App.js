import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles'

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';

import EmployeePairsTable from './components/EmployeePairTable'
import UploadCSVDialog from './components/UploadCSVDialog'

const styles = makeStyles(theme => ({
	root: {
		width: '60%',
		marginTop: theme.spacing.unit * 3,
		overflowX: 'auto',
	},
	table: {
		minWidth: 400,
	},
}));

let id = 0;

function createData(name, calories, fat, carbs, protein) {
	id += 1;
	return { id, name, calories, fat, carbs, protein };
}


function App() {	
	const [rows, setRows] = useState([])
	const [uploadDialogOpen, setUploadDialogOpen] = useState(false)
	
	useEffect(() => {
		fetch("/employees/test")
		.then(response => response.json())
		.then(data => {
			setRows([])
			})
		.catch(error => console.warn(error));
	}, []);


	return (
		<div className="App">
			<header className="App-header">
				<img src={logo} className="App-logo" alt="logo" />
			</header>
			<body>
			
			<div style={{ margin: 32 }}>
		      	<Button variant="contained" color="primary" component="span" onClick={() => setUploadDialogOpen(true)}>
	          	Upload CSV
	        	</Button>
		    </div>
        	
			<EmployeePairsTable rows={rows}/>
			</body>
		<UploadCSVDialog handleResponseFunc={(data) => setRows(data)} setOpenFunc={setUploadDialogOpen} open={uploadDialogOpen} />
		</div>

	);
}

export default App;
